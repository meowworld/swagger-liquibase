package com.example.swagger.test;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@ApiModel(value = "User", description = "用户实体")
public class User {

    @ApiModelProperty(value = "姓名",example = "hahah")
    @NotBlank(message = "投保人姓名不能为空")
    private String name;

    @ApiModelProperty(value = "年龄",example = "18")
    @Min(value = 0)
    private Integer age;



}
