package com.example.swagger.test;


import io.swagger.annotations.*;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

@Api(tags = "产品信息222",description = "产品信息操作接口222")
@RestController
@RequestMapping("/admin222/user")
public class TestController {


    @ApiOperation(value = "保单详细信息查询接口222",notes = "保单详细信息查询接口",httpMethod = "GET",
            produces = MediaType.APPLICATION_JSON_VALUE ,response = Map.class)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name",value = "用户名",required = true ,paramType = "query",dataType = "String"),
            @ApiImplicitParam(name = "password",value = "密码",required = true ,paramType = "query",dataType = "String")
    })
    @ApiResponses({
            @ApiResponse(code = 200,message = "查询成功" , response = Map.class)
    })

    @GetMapping("/policyDetail2222")
    public Map queryDetail(String name , String password , HttpServletRequest request){
        HashMap hashMap = new HashMap();
        hashMap.put("1","hehe");
        return hashMap;
    }


    @ApiOperation(value = "保单详细信息保存222",notes = "保单详细信息保存",httpMethod = "POST",
            produces = MediaType.APPLICATION_JSON_VALUE ,response = User.class)
    @ApiImplicitParams({})
    @ApiResponses({
            @ApiResponse(code = 200,message = "查询成功" , response = User.class)
    })
    @PostMapping("/save222")
    public User create(User user){
        return new User();
    }


}
